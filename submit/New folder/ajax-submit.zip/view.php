<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Bootstrap Modal with Dynamic MySQL Data using Ajax & PHP</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>

<div class="container">
	<div class="page-header">
		<h3><a href="#">Modal with Dynamic Mysql Data using AJAX & PHP</a></h3>
	</div>

	<div class="row">
		<div class="col-lg-12">
			<table class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Full Name</th>
						<th>View Profile</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$dbhost = 'localhost';
					$dbuser = 'root';
					$dbpass = '';
					$dbname = 'ajax-jquery-php';


					$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

					if($conn->connect_error){
						die('Connection Error :'.$conn->connect_error);
					}
					$sql = "SELECT * FROM biodata";
					$data = $conn->query($sql);
					while($row = $data->fetch_array()){

					 ?>
					 <tr>
					 	<td><?php echo $row['fname']."&nbsp;".$row['lname'];?>
					 	</td>
					 	<td>
					 		<button data-toggle="modal" data-target="#view-modal" data-id="<?php echo $row['id'];?>" id="getUser" class="btn btn-sm btn-info"><i class="glyphicon glyphicon-eye-open"></i>View</button>
					 	</td>
					 </tr>
					 <?php
					}
					?>
					
				</tbody>
			</table>
		</div>
	</div>

	<div class="modal fade" id="view-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: :none;">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button class="close" type="button" data-dismiss="modal" aria-hidden="true">x</button>
					<h4 class="modal-title">
	                	<i class="glyphicon glyphicon-user"></i> User Profile
	                </h4> 
				</div>
				<div class="modal-body">
					<div id="modal-loader" style="display: none; text-align: center;">
						<img src="">
					</div>
					<!--Content will be loaded here-->
					<div id="dynamic-content">
						<!-- Kalo Data Type JSON-->
					  <div class="row"> 
                            <div class="col-md-12"> 
                            	
                            	<div class="table-responsive">
                            	
                                <table class="table table-striped table-bordered">
                           		<tr>
                            	<th>First Name</th>
                            	<td id="txt_fname"></td>
                                </tr>
                                     
                                <tr>
                            	<th>Last Name</th>
                            	<td id="txt_lname"></td>
                                </tr>
                                       		
                                <tr>
                                <th>Email ID</th>
                                <td id="txt_email"></td>
                                </tr>
                                       		
                                <tr>
                                <th>Position</th>
                                <td id="txt_position"></td>
                                </tr>
                                       		
                                </table>
                                
                                </div>
                                       
                            </div> 
                          </div>
                         <!--End Tabel Data Type JSON-->

					</div>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="assets/jquery-1.12.4-jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','#getUser', function(e){
		e.preventDefault();
		var uid = $(this).data('id');
		$('#dynamic-content').hide();

		$.ajax({
			type:'POST',
			url:'submit2.php',
			data:{id:uid},
			dataType:'json'
		}).done(function(data){
			console.log(data);
			$('#dynamic-content').show(); // show dynamic div
			$('#txt_fname').html(data.fname);
			$('#txt_lname').html(data.lname);
			$('#txt_email').html(data.email);
			$('#txt_position').html(data.phone);
		}).fail(function(){

			$('.modal-body').html('<i class="glyphicon glyphicon-info-sign"></i> Something went wrong, Please try again...');
		});
	});
});
</script>


</body>
</html>