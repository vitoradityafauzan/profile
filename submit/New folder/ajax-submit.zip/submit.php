<?php

	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$dbname = 'ajax-jquery-php';


	$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

	if($conn->connect_error){
		die('Connection Error :'.$conn->connect_error);
	}
	
if($_POST){
	$fname = $_POST['txt_fname'];
	$lname = $_POST['txt_lname'];
	$email = $_POST['txt_email'];
	$phno = $_POST['txt_contact'];


	$sql = "INSERT INTO biodata (fname, lname, email, phone) VALUES('$fname', '$lname', '$email','$phno')";

	if($conn->query($sql)){

		?>
		<div class="alert alert-info">
			<strong>Data Submitted Successfully</strong>
		</div>
		<?php
	}else{

		?>
		<div class="alert alert-danger">
			<strong>Failed Submit Data</strong>
		</div>

		<?php
	}
}
$conn->close();


?>


